<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pendaftaran Peserta - portal PMB</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">

</head>

<body class="index-page">
    <?php include 'header.php'; ?>
    <main class="main">
        <section id="hero" class="hero section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <h2>Pendaftaran Peserta</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Konfirmasi password</label>
                        <input type="confirm_password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" required>
                    </div>
                    <div class="mb-3">
                        <label for="sekolah_asal" class="form-label">Sekolah Asal</label>
                        <input type="text" class="form-control" id="sekolah_asal" name="sekolah_asal" required>
                    </div>
                    <div class="mb-3">
                        <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                        <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" required>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                        <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                    </div>
                    <div class="mb-3">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                        <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="prodi" class="form-label">Jenis Kelamin</label>
                        <select class="form-control" id="prodi" name="prodi" required>
                            <?php
                            include 'conn.php';

                            // Menampilkan data peserta
                            $s = "SELECT * FROM tb_prodi";
                            $q = $conn->query($s);

                            $tr = '';
                            $i = 0;
                            while ($d = $q->fetch_assoc()) {  // Mengubah menjadi fetch_assoc untuk mendapatkan array asosiatif
                                $i++;
                            ?>
                                <option value="<?= $d['id'] ?>"><?= $d['nama_prodi'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="photo_profil" class="form-label">Foto Profil</label>
                        <input type="file" class="form-control" id="photo_profil" name="photo_profil" required>
                    </div>
                    <div class="mb-3">
                        <label for="file_ijazah" class="form-label">File Ijazah</label>
                        <input type="file" class="form-control" id="file_ijazah" name="file_ijazah" required>
                    </div>
                    <button type="submit" name="btn_daftar" class="btn btn-primary">Daftar</button>
                    <a href="data_peserta.php" class="btn btn-secondary">Kembali</a>
                </form>

                <?php
                include 'conn.php';

                // Proses pendaftaran jika form disubmit
                if (isset($_POST['btn_daftar'])) {
                    $nama = $_POST['nama'];
                    $email = $_POST['email'];
                    $alamat = $_POST['alamat'];
                    $sekolah_asal = $_POST['sekolah_asal'];
                    $tempat_lahir = $_POST['tempat_lahir'];
                    $tanggal_lahir = $_POST['tanggal_lahir'];
                    $jenis_kelamin = $_POST['jenis_kelamin'];
                    $prodi = $_POST['prodi'];  // Assumed to be the ID of the program
                    $password = $_POST['password'];
                    $confirm_password = $_POST['confirm_password'];

                    // Validate required fields (optional)
                    if (empty($nama) || empty($email) || empty($alamat) || empty($sekolah_asal) || empty($tempat_lahir) || empty($tanggal_lahir) || empty($jenis_kelamin) || empty($prodi) || empty($password) || empty($confirm_password)) {
                        echo "<div class='alert alert-danger'>Semua bidang harus diisi!</div>";
                        exit;
                    }

                    // Validate password (at least 8 characters, includes both letters and numbers)
                    if (strlen($password) < 3) {
                        echo "<div class='alert alert-danger'>Password harus minimal 3 karakter dan mengandung huruf serta angka.</div>";
                        exit;
                    }

                    // Check if password and confirm_password match
                    if ($password !== $confirm_password) {
                        echo "<div class='alert alert-danger'>Password dan konfirmasi password tidak cocok.</div>";
                        exit;
                    }

                    // Hash the password before storing
                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                    // Handle upload file foto profil
                    if (isset($_FILES['photo_profil']) && $_FILES['photo_profil']['error'] == 0) {
                        $target_dir = "assets/img/";  // Direktori untuk menyimpan gambar
                        $target_file_photo = $target_dir . basename($_FILES["photo_profil"]["name"]);
                        $imageFileType = strtolower(pathinfo($target_file_photo, PATHINFO_EXTENSION));

                        // Validasi file foto profil
                        if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                            echo "<div class='alert alert-danger'>Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan untuk foto profil.</div>";
                        } else {
                            if (move_uploaded_file($_FILES["photo_profil"]["tmp_name"], $target_file_photo)) {
                                // Handle upload file ijazah
                                if (isset($_FILES['file_ijazah']) && $_FILES['file_ijazah']['error'] == 0) {
                                    $target_file_ijazah = $target_dir . basename($_FILES["file_ijazah"]["name"]);
                                    $fileType = strtolower(pathinfo($target_file_ijazah, PATHINFO_EXTENSION));

                                    // Validasi file ijazah
                                    if (!in_array($fileType, ['pdf', 'jpg', 'jpeg', 'png'])) {
                                        echo "<div class='alert alert-danger'>Maaf, hanya file PDF, JPG, JPEG & PNG yang diperbolehkan untuk ijazah.</div>";
                                    } else {
                                        if (move_uploaded_file($_FILES["file_ijazah"]["tmp_name"], $target_file_ijazah)) {
                                            // Simpan data peserta dan file yang diupload, including hashed password
                                            $stmt = $conn->prepare("INSERT INTO tb_peserta (nama, email, alamat, sekolah_asal, tempat_lahir, tanggal_lahir, jenis_kelamin, photo_profil, ijazah, prodi_id, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                                            $stmt->bind_param("sssssssssis", $nama, $email, $alamat, $sekolah_asal, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $target_file_photo, $target_file_ijazah, $prodi, $hashed_password); // Added 's' for hashed_password

                                            if ($stmt->execute()) {
                                                echo "<div class='alert alert-success'>Pendaftaran berhasil!</div>";
                                                echo "<script>location.replace('data_peserta.php');</script>"; // Kembali ke halaman data peserta
                                            } else {
                                                echo "<div class='alert alert-danger'>Terjadi kesalahan saat mendaftar peserta.</div>";
                                            }
                                        } else {
                                            echo "<div class='alert alert-danger'>Maaf, terjadi kesalahan saat mengunggah file ijazah.</div>";
                                        }
                                    }
                                } else {
                                    echo "<div class='alert alert-danger'>Tidak ada file ijazah yang diunggah.</div>";
                                }
                            } else {
                                echo "<div class='alert alert-danger'>Maaf, terjadi kesalahan saat mengunggah file foto profil.</div>";
                            }
                        }
                    } else {
                        echo "<div class='alert alert-danger'>Tidak ada file foto profil yang diunggah.</div>";
                    }
                }
                ?>


            </div>
        </section>
    </main>

    <footer id="footer" class="footer position-relative light-background">
        <div class="container footer-top">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6 footer-about">
                    <a href="index.html" class="logo d-flex align-items-center">
                        <span class="sitename">Mentor</span>
                    </a>
                    <div class="footer-contact pt-3">
                        <p>A108 Adam Street</p>
                        <p>New York, NY 535022</p>
                        <p class="mt-3"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
                        <p><strong>Email:</strong> <span>contact@company.com</span></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>