        <?php
        if (!isset($_SESSION)) {
          session_start();
        }
        ?>
        ,
        <header id="header" class="header d-flex align-items-center fixed-top">
          <div class="header-container container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

            <a href="index.html" class="logo d-flex align-items-center me-auto me-xl-0">
              <!-- Uncomment the line below if you also wish to use an image logo -->
              <!-- <img src="assets/img/logo.png" alt=""> -->
              <h1 class="sitename">PMB</h1>
            </a>

            <?php if (isset($_SESSION['username'])) { ?>
              <nav id="navmenu" class="navmenu">
                <ul>
                  <li><a href="home.php">Home</a></li>
                  <li><a href="data_peserta.php">Data Peserta</a></li>
                  <li><a href="pendaftaran.php">Pendaftaran</a></li>
                  <li><a href="data_prodi.php">Data Prodi</a></li>
                  <li><a href="data_fakultas.php">Data fakultas</a></li>
                  <li><a href="?laporan_pmb">Laporan PMB</a></li>
                  </li>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
              </nav>
              <a class="btn btn-success" href="#"><?= $_SESSION['username'] . " | " . $_SESSION['role'] ?></a>
              <a class="btn-getstarted" href="logout.php">Logout</a>
            <?php } else { ?>
              <a class="btn-getstarted m-1" href="login.php">Login</a>
            <?php } ?>
          </div>
        </header>