<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pendaftaran Program Studi - portal PMB</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">

</head>

<body class="index-page">
    <?php include 'header.php'; ?>
    <main class="main">
        <section id="hero" class="hero section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row">
                    <div class="col-6">
                        <h2>Pendaftaran Program Studi</h2>
                        <form method="POST" enctype="multipart/form-data" style="margin-left:auto; margin-right:auto">
                            <div class="mb-3">
                                <label for="nama_prodi" class="form-label">Nama Program Studi</label>
                                <input type="text" class="form-control" id="nama_prodi" name="nama_prodi" required>
                            </div>
                            <button type="submit" name="btn_daftar_prodi" class="btn btn-primary">Tambah Prodi</button>
                        </form>
                    </div>
                    <div class="col-6">
                        <table class="table">
                            <tr>
                                <th>ID</th>
                                <th>Nama Prodi</th>
                                <th>Aksi</th>
                            </tr>
                            <?php
                            include 'conn.php';

                            // Menampilkan data peserta
                            $s = "SELECT * FROM tb_prodi";
                            $q = $conn->query($s);

                            $tr = '';
                            $i = 0;
                            if ($q->num_rows < 1) {
                                echo "<tr><td colspan='3'>Data Prodi Kosong</td></tr>";
                            }
                            while ($d = $q->fetch_assoc()) {  // Mengubah menjadi fetch_assoc untuk mendapatkan array asosiatif
                                $i++;
                            ?>
                                <tr>
                                    <td><?= $d['id'] ?></td>
                                    <td><?= $d['nama_prodi'] ?></td>
                                    <td>
                                        <!-- Tombol Edit -->
                                        <a class='btn btn-sm btn-info' href='edit_prodi.php?id=<?= $d["id"] ?>'>Edit</a>

                                        <!-- Tombol Delete -->
                                        <form method='post' style='display:inline' onsubmit="return confirm('Yakin mau hapus peserta ini?');">
                                            <button name='btn_delete' value='<?= $d['id'] ?>' class='btn btn-sm btn-danger'>Delete</button>
                                        </form>

                                    </td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>

                <?php
                include 'conn.php';

                // Proses pendaftaran jika form disubmit
                if (isset($_POST['btn_daftar_prodi'])) {
                    $nama_prodi = $_POST['nama_prodi'];

                    // Simpan data program studi ke database
                    $stmt = $conn->prepare("INSERT INTO tb_prodi (nama_prodi) VALUES (?)");
                    $stmt->bind_param("s", $nama_prodi); // Corrected the bind_param with a single string type "s"

                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>Pendaftaran program studi berhasil!</div>";
                        echo "<script>location.replace('data_prodi.php');</script>"; // Kembali ke halaman data program studi
                    } else {
                        echo "<div class='alert alert-danger'>Terjadi kesalahan saat mendaftar program studi.</div>";
                    }
                }
                if (isset($_POST['btn_delete'])) {
                    $id = $_POST['btn_delete']; // Retrieve the id from the form submission

                    // Delete the record from the database
                    $stmt = $conn->prepare("DELETE FROM tb_prodi WHERE id = ?");
                    $stmt->bind_param("i", $id); // Bind the id as an integer

                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>prodi berhasil dihapus!</div>";
                        echo "<script>location.replace('data_prodi.php');</script>"; // Redirect to the main data page
                    } else {
                        echo "<div class='alert alert-danger'>Terjadi kesalahan saat menghapus prodi.</div>";
                    }
                }
                ?>

            </div>
        </section>
    </main>

    <footer id="footer" class="footer position-relative light-background">
        <div class="container footer-top">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6 footer-about">
                    <a href="index.html" class="logo d-flex align-items-center">
                        <span class="sitename">Mentor</span>
                    </a>
                    <div class="footer-contact pt-3">
                        <p>A108 Adam Street</p>
                        <p>New York, NY 535022</p>
                        <p class="mt-3"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
                        <p><strong>Email:</strong> <span>info@example.com</span></p>
                    </div>
                    <div class="social-links d-flex mt-4">
                        <a href="#"><i class="bi bi-twitter-x"></i></a>
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 footer-links">
                    <h4>Tautan Berguna</h4>
                    <ul>
                        <li><a href="#">Beranda</a></li>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Layanan</a></li>
                        <li><a href="#">Syarat Layanan</a></li>
                        <li><a href="#">Kebijakan Privasi</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 footer-newsletter">
                    <h4>Newsletter Kami</h4>
                    <p>Langganan newsletter kami dan dapatkan berita terbaru tentang produk dan layanan kami!</p>
                    <form action="forms/newsletter.php" method="post" class="php-email-form">
                        <div class="newsletter-form">
                            <input type="email" name="email" required>
                            <input type="submit" value="Langganan">
                        </div>
                        <div class="loading">Memuat...</div>
                        <div class="error-message"></div>
                        <div class="sent-message">Permintaan langganan Anda telah dikirim. Terima kasih!</div>
                    </form>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>