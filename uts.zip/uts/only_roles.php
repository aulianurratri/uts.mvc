<?php
function only_roles($arr_role)
{
    $boleh_akses = false;
    if (is_array($arr_role)){

        foreach ($arr_role as $role) {
            if ($role == $_SESSION['role']){
                $boleh_akses = true;
                break;
            }
        }
    }

    if (!$boleh_akses){
        die("<b style=color:red>Maaf, hak akses anda ($_SESSION[role]) tidak berhak mengakses page ini.</b>");
    }
}