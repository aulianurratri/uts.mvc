<h1>Dashboard</h1>
<?php
//inisialisasi
session_start();

//tampung data session
$username = $_SESSION['dipa_username']??'';
if(!$username){
    //tampilkan error dan stop
    echo "maaf, anda belum login";
    exit;
}


echo '<pre>';
echo var_dump($_SESSION);
echo '</pre>';

echo "selamat datang $_SESSION[dipa_username], anda login sebagai $_SESSION[dipa_sebagai]";

echo '<hr>';
echo $_SESSION['dipa_username']? 'data penting untuk dosen': '';