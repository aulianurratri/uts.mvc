<h1>PHP Session</h1>
<?php
//inisialisasi
session_start();


$_SESSION['dipa_username'] = 'aulia';
$_SESSION['dipa_sebagai'] = 'mahasiswa';

echo '<hr>set session berhasil. anda sudah login.';



echo '<pre>';
echo var_dump($_SESSION);
echo '</pre>';