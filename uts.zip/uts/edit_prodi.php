<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pendaftaran Program Studi - portal PMB</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">

</head>

<body class="index-page">
    <?php include 'header.php'; ?>
    <main class="main">
        <section id="hero" class="hero section">
            <div class="container" data-aos="fade-up" data-aos-delay="100">
                <div class="row">
                    <div class="col-12">
                        <h2>Pendaftaran Program Studi</h2>
                        <form method="POST" enctype="multipart/form-data" style="margin-left:auto; margin-right:auto">
                            <?php
                            include 'conn.php';

                            // Menampilkan data peserta
                            $stmt = $conn->prepare("SELECT * FROM tb_prodi where id = ?");
                            $stmt->bind_param("i", $_GET['id']);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $data = $result->fetch_assoc();

                            ?>
                            <div class="mb-3">
                                <label for="nama_prodi" class="form-label">Nama Program Studi</label>
                                <input type="text" class="form-control" id="nama_prodi" name="nama_prodi" value="<?= $data['nama_prodi']  ?>" required>
                            </div>
                            <button type="submit" name="btn_edit_prodi" class="btn btn-primary">edit</button>
                        </form>
                    </div>

                </div>

                <?php
                include 'conn.php';

                if (isset($_POST['btn_edit_prodi'])) {
                    $id = $_GET['id']; // Assuming 'id' is sent through POST for identifying the record to update
                    $nama_prodi = $_POST['nama_prodi'];

                    // Update data program studi in the database
                    $stmt = $conn->prepare("UPDATE tb_prodi SET nama_prodi = ? WHERE id = ?");
                    $stmt->bind_param("si", $nama_prodi, $id); // Bind 'nama_prodi' as string and 'id' as integer

                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>Update program studi berhasil!</div>";
                        echo "<script>location.replace('data_prodi.php');</script>"; // Kembali ke halaman data program studi
                    } else {
                        echo "<div class='alert alert-danger'>Terjadi kesalahan saat memperbarui program studi.</div>";
                    }
                }
                ?>

            </div>
        </section>
    </main>

    <footer id="footer" class="footer position-relative light-background">
        <div class="container footer-top">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6 footer-about">
                    <a href="index.html" class="logo d-flex align-items-center">
                        <span class="sitename">Mentor</span>
                    </a>
                    <div class="footer-contact pt-3">
                        <p>A108 Adam Street</p>
                        <p>New York, NY 535022</p>
                        <p class="mt-3"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
                        <p><strong>Email:</strong> <span>info@example.com</span></p>
                    </div>
                    <div class="social-links d-flex mt-4">
                        <a href="#"><i class="bi bi-twitter-x"></i></a>
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 footer-links">
                    <h4>Tautan Berguna</h4>
                    <ul>
                        <li><a href="#">Beranda</a></li>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Layanan</a></li>
                        <li><a href="#">Syarat Layanan</a></li>
                        <li><a href="#">Kebijakan Privasi</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 footer-newsletter">
                    <h4>Newsletter Kami</h4>
                    <p>Langganan newsletter kami dan dapatkan berita terbaru tentang produk dan layanan kami!</p>
                    <form action="forms/newsletter.php" method="post" class="php-email-form">
                        <div class="newsletter-form">
                            <input type="email" name="email" required>
                            <input type="submit" value="Langganan">
                        </div>
                        <div class="loading">Memuat...</div>
                        <div class="error-message"></div>
                        <div class="sent-message">Permintaan langganan Anda telah dikirim. Terima kasih!</div>
                    </form>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>