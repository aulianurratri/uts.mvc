<?php
session_start();
include 'conn.php';
include 'header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query menggunakan prepared statement untuk keamanan
    $query = $conn->prepare("SELECT * FROM tb_peserta WHERE email = ?");
    $query->bind_param('s', $username);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verifikasi password yang sudah di-hash
        if (sha1($password) == $user['password']) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = 'peserta';
            header('Location: data_peserta.php');
            exit();
        } else {
            $error = "Username/email atau password salah!";
        }
    } else {
        $query = $conn->prepare("SELECT * FROM tb_user as a join tb_role as b on a.role=b.id WHERE username = ?");
        $query->bind_param('s', $username);
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            // Verifikasi password yang sudah di-hash
            if (sha1($password) == $user['password']) {
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $user['jabatan'];
                header('Location: data_peserta.php');
                exit();
            } else {
                $error = "Username/email atau password salah!";
            }
        } else {
            $error = "Username/email atau password salah!";
        }
        $error = "Username/email atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Login</title>

    <!-- Tambahkan semua link CSS Bootstrap yang sudah disebutkan sebelumnya -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet">

    <style>
        /* CSS untuk menengahkannya secara vertikal dan horizontal */
        .login-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            width: 100%;
            max-width: 300px;
            /* Mengubah lebar menjadi lebih kecil */
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .register-link {
            text-align: center;
            margin-top: 15px;
        }

        .register-link a {
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <div class="container login-container">
        <div class="login-box">
            <h1 class="text-center mb-4">Login</h1>

            <form method="POST" action="">
                <div class="form-group mb-3">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" class="form-control" required>
                </div>

                <div class="form-group mb-3">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>

            <?php if (isset($error)) {
                echo "<div class='alert alert-danger mt-3'>$error</div>";
            } ?>

            <!-- Tautan untuk pendaftaran akun baru -->
            <div class="register-link">
                <p>Belum punya akun? <a href="pendaftaran_akun.php">Daftar di sini</a></p>
            </div>
        </div>
    </div>

    <footer id="footer" class="footer position-relative light-background">
        <div class="container footer-top">
            <div class="row gy-4">
                <div class="col-lg-4 col-md-6 footer-about">
                    <a href="index.html" class="logo d-flex align-items-center">
                        <span class="sitename">Mentor</span>
                    </a>
                    <div class="footer-contact pt-3">
                        <p>A108 Adam Street</p>
                        <p>New York, NY 535022</p>
                        <p class="mt-3"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
                        <p><strong>Email:</strong> <span>info@example.com</span></p>
                    </div>
                    <div class="social-links d-flex mt-4">
                        <a href="#"><i class="bi bi-twitter-x"></i></a>
                        <a href="#"><i class="bi bi-facebook"></i></a>
                        <a href="#"><i class="bi bi-instagram"></i></a>
                        <a href="#"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 footer-links">
                    <h4>Tautan Berguna</h4>
                    <ul>
                        <li><a href="#">Beranda</a></li>
                        <li><a href="#">Tentang Kami</a></li>
                        <li><a href="#">Layanan</a></li>
                        <li><a href="#">Syarat Layanan</a></li>
                        <li><a href="#">Kebijakan Privasi</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12 footer-newsletter">
                    <h4>Newsletter Kami</h4>
                    <p>Langganan newsletter kami dan dapatkan berita terbaru tentang produk dan layanan kami!</p>
                    <form action="forms/newsletter.php" method="post" class="php-email-form">
                        <div class="newsletter-form">
                            <input type="email" name="email" required>
                            <input type="submit" value="Langganan">
                        </div>
                        <div class="loading">Memuat...</div>
                        <div class="error-message"></div>
                        <div class="sent-message">Permintaan langganan Anda telah dikirim. Terima kasih!</div>
                    </form>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS dan dependencies -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>