<?php
$conn = mysqli_connect(
    'localhost',
    'root',
    '',
    'uts_aulia'
);
?>