<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Home - Penerimaan Mahasiswa Baru</title>
    <meta name="description" content="Portal Penerimaan Mahasiswa Baru">
    <meta name="keywords" content="PMB, Pendaftaran Mahasiswa Baru, Universitas, Sekolah Tinggi">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">
</head>

<body class="index-page">
    <?php include 'header.php'; ?>

    <main class="main">
        <!-- Hero Section -->
        <section id="hero" class="hero section">
            <div class="container text-center" data-aos="fade-up" data-aos-delay="100">
                <h1>Selamat Datang di Portal Penerimaan Mahasiswa Baru</h1>
                <p class="lead">Ma'soem University menyambut calon mahasiswa untuk bergabung dengan kami. Daftarkan diri Anda sekarang dan jadilah bagian dari masa depan yang lebih baik!</p>
                <a href="login.php" class="btn btn-primary">Daftar Sekarang</a>
            </div>
        </section>
        <footer id="footer" class="footer position-relative light-background">
            <div class="container footer-top">
                <div class="row gy-4">
                    <div class="col-lg-4 col-md-6 footer-about">
                        <a href="index.html" class="logo d-flex align-items-center">
                            <span class="sitename">Mentor</span>
                        </a>
                        <div class="footer-contact pt-3">
                            <p>A108 Adam Street</p>
                            <p>New York, NY 535022</p>
                            <p class="mt-3"><strong>Phone:</strong> <span>+1 5589 55488 55</span></p>
                            <p><strong>Email:</strong> <span>info@example.com</span></p>
                        </div>
                        <div class="social-links d-flex mt-4">
                            <a href="#"><i class="bi bi-twitter-x"></i></a>
                            <a href="#"><i class="bi bi-facebook"></i></a>
                            <a href="#"><i class="bi bi-instagram"></i></a>
                            <a href="#"><i class="bi bi-linkedin"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 footer-links">
                        <h4>Tautan Berguna</h4>
                        <ul>
                            <li><a href="#">Beranda</a></li>
                            <li><a href="#">Tentang Kami</a></li>
                            <li><a href="#">Layanan</a></li>
                            <li><a href="#">Syarat Layanan</a></li>
                            <li><a href="#">Kebijakan Privasi</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-12 footer-newsletter">
                        <h4>Newsletter Kami</h4>
                        <p>Langganan newsletter kami dan dapatkan berita terbaru tentang produk dan layanan kami!</p>
                        <form action="forms/newsletter.php" method="post" class="php-email-form">
                            <div class="newsletter-form">
                                <input type="email" name="email" required>
                                <input type="submit" value="Langganan">
                            </div>
                            <div class="loading">Memuat...</div>
                            <div class="error-message"></div>
                            <div class="sent-message">Permintaan langganan Anda telah dikirim. Terima kasih!</div>
                        </form>
                    </div>
                </div>
            </div>
        </footer>


        <!-- Vendor JS Files -->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/main.js"></script>
</body>

</html>